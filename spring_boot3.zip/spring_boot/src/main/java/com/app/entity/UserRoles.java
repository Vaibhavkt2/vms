package com.app.entity;

public enum UserRoles {
	ADMIN, SALESPERSON, USERS
}
